#include<stdio.h>

void microkernel_sendmsg(char *);

//I did this for Step30

void main(){
        printf("Helloworld!\n");
        printf("This must be a monolithic design\n");
        microkernel_sendmsg("is more portable");
        //This is another change for Step30
}

void microkernel_sendmsg(char *a){
        printf("microkernel: %s\n", a);
}
